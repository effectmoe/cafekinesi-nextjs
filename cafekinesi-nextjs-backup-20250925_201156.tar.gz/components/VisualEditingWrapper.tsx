'use client'

export function VisualEditingWrapper() {
  // Visual editing disabled - package removed to fix auth error
  return null
}